from flask import Flask, jsonify, request
import serial
import psycopg2
import os
from config import DATABASE_CONFIG  # Импорт конфигурации базы данных

app = Flask(__name__)


def get_com_port_from_db(order_id):
    conn = None
    try:
        conn = psycopg2.connect(**DATABASE_CONFIG)
        cursor = conn.cursor()
        # Запрос для получения COM порта по order_id
        sql = """
        SELECT com_port FROM printer_threedprinteruser
        WHERE id = (
            SELECT printer_id FROM printer_order WHERE id = %s
        )
        """
        cursor.execute(sql, (order_id,))
        result = cursor.fetchone()
        return result[0] if result else None
    except (Exception, psycopg2.Error) as error:
        print("Ошибка при получении COM порта из базы данных:", error)
        return None
    finally:
        if conn:
            cursor.close()
            conn.close()


@app.route('/')
def home():
    return "Hello, Flask!"


@app.route('/print', methods=['POST'])
def print_model():
    if 'model_file' not in request.files or 'order_id' not in request.form:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

    model_file = request.files['model_file']
    order_id = request.form['order_id']
    save_directory = "/path/to/save"  # Replace with your desired directory
    if not os.path.exists(save_directory):
        os.makedirs(save_directory)
    file_path = os.path.join(save_directory, model_file.filename)
    model_file.save(file_path)

    com_port = get_com_port_from_db(order_id)
    if not com_port:
        return jsonify({'status': 'error', 'message': 'COM port not found for the specified order'}), 400

    try:
        ser = serial.Serial(com_port, 115200, timeout=1)
        with open(file_path, 'rb') as f:
            ser.write(f.read())  # Send model data to the printer
        ser.close()
        return jsonify({'status': 'success', 'message': 'Model sent to printer.'}), 200
    except serial.SerialException as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)