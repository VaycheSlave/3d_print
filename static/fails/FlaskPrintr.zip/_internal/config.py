DATABASE_CONFIG = {
    'dbname': 'printdb',
    'user': 'postgres',
    'password': 'Slava2000',
    'host': '192.168.3.29',
    'port': '5432'
}